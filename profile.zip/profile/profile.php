<?php
include('dbconnection.php');
?>
<html>
<head>
	<style>
		#logout
		{
			float:right;
		}
		body{
			background-color: white;
		}
		ul{ 
			list-style-type: none;
			margin: 0%;
			padding: 0%;
			width: 100%;
			background-color: gray;
			overflow: hidden;
		}
		li a{
			display: block;
			padding:20px 20px;
			float:left;
			text-decoration: none;
			color: white;
		}
		li{
			float:left;
		}
		fieldset{
			border:none;
		}
		h1{
			color:orange;
			text-align:center;
			position: sticky;
			margin-top: 0px;
			margin: auto;
			height:10%;
			width:100%;
		}
		input{
			padding: 5px;
			width: 100%;
			color:black;
		}
		button{
			padding: 5px;
			width:97%;
			margin-left: 11px; 
		}
		button:hover,input:hover{
			font-size: 100%;
			background-color: white;
			color:black;
		}
		input:active{
			border-style: solid;
			border-radius: 12px;
			border-color: red;
		}
		a:hover{
			background-color: green;
		}
		#profileview
		{
			height:70%;
			width:50%;
			margin: auto;
			border-style: solid;
			border-color: deeppink;
			background-color: black;
			color:gold;
			box-sizing: border-box;
		}
	</style>
</head>
<body>
	<ul>
		<li><a href="#home">Home</a></li>
		<li id="logout"><a href="ssdestroy.php">Logout</a></li>
	</ul>
	<h1>your profile details</h1>
	<script>
		function formenable()
		{
			document.getElementById("profile").disabled=false;
		}
	</script>
	<?php
	$username=$_SESSION["username"];
	//echo $username;
	$sql="select * from userdetails where username='$username'";
	$result=$conn->query($sql);
	$qvalue=$result->fetch_assoc();
	$username=$qvalue["username"];
	$firstname=$qvalue["firstname"];
	$lastname=$qvalue["lastname"];
	$dob=$qvalue["dob"];
	$phone_no=$qvalue["phoneno"];
	$mail=$qvalue["mail"];
	echo "<div id='profileview'>";
	echo "<form method='post'>";
	echo "<fieldset disabled='disabled' id='profile'>";
	echo "<label for='firstname'>Firstname:</label>";
	echo "<input type='text' name='first_name' value='$firstname'required></input><br>";
	echo "<p id='fname'></p>";
	echo "<label for='lastname'>Lastname:</label>";
	echo "<input type='text' name='last_name' value='$lastname'required></input><br>";
	echo "<p id='lname'></p>";
	echo "<label for='Date of Birth'>Date of Birth:</label>";
	echo "<input type='date' name='dob' value='$dob'required></input><br>";
	echo "<p id='date'></p>";
	echo "<label for='Phone no'>Phone no:</label>";
	echo "<input type='tel' name='phoneno' minlength='10' maxlength='10' value='$phone_no'required></input><br>";
	echo "<p id='phoneno'></p>";
	echo "<label for='Mail'>Mail:</label>";
	echo "<input type='mail' name='mail' value='$mail'required></input><br>";
	echo "<p id='mailid'></p>";
	echo "<input type='submit' value='submit'></input>";
	echo "</fieldset>";
	echo "</form>";
	echo "<button onclick='formenable()' value='for update'>For update</button>";
	echo "</div>";
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$firstname=firstchecking($_POST["first_name"]);
		$lastname=lastchecking($_POST["last_name"]);
		$dob=$_POST["dob"];
		$phone_no=phonenochecking($_POST["phoneno"]);
		$mailid=mailchecking($_POST["mail"]);
		$sql="update userdetails set firstname='$firstname',lastname='$lastname',dob='$dob',phoneno='$phone_no',mail='$mailid' where username='$username'";
		if($result=$conn->query($sql))
		{
			echo"<script>alert('your details updated successfully');</script>";
			echo"<script>location.assign('profile.php');</script>";
		}
	}
	function firstchecking($textvalue)
	{
		if(!(preg_match('/[.]|[\'^£$%&*()}{@#~?><>,|=_+¬-],|[0-9]/', $textvalue)))
		{
			return $textvalue;						
		}
		else
		{
			echo "<script> var a=<?php echo $id; ?>;
			document.getElementById('fname').innerHTML='*invalid input'</script>";
			exit();
		}

	}
	function lastchecking($textvalue)
	{
		if(!(preg_match('/[.]|[\'^£$%&*()}{@#~?><>,|=_+¬-],|[0-9]/', $textvalue)))
		{
			return $textvalue;						
		}
		else
		{
			echo "<script>document.getElementById('fname').innerHTML='*invalid input'</script>";
			exit();
		}

	}
	function phonenochecking($phoneno)
	{
		if(!(preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]|[A-Z]|[a-z]|[.]/', $phoneno)))
		{
			return $phoneno;
		}
		else
		{
			echo "<script>document.getElementById('phoneno').innerHTML='*invalid input'</script>";
			exit();
		}
	}
	function mailchecking($mailid)
	{

		if(filter_var($mailid, FILTER_VALIDATE_EMAIL))
		{
			return $mailid;
		}
		else{
			echo "<script>document.getElementById('mailid').innerHTML='*inavlid input'</script>";	
			exit();
		}
	}
	?>
</body>
</html>
