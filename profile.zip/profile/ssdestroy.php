<?php
include('dbconnection.php');
session_destroy();
echo "<script>alert('Thank you for visitng')</script>";
echo "<script>location.replace('login.php')</script>";
?>
