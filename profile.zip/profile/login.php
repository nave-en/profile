<?php
include("dbconnection.php");
?>
<html>
<head>
	<meta name="viewport" content="width=intial-width intialscale=1.0">
	<title>login</title>
	<style>
		h1{
			text-align: center;
			background-color: gray;
			margin-top: 0%;
		}
		form
		{
			height: 30%;
			width: 30%;
			border-style: solid;
			border-color: yellow;
			margin:auto;
			padding:40px;
		}

		input[type=submit]
		{
			margin-bottom:0;
			height:20%;
			width:20%;
			border-radius: 12px;
		}
		input[type=submit]:hover{
			background-color: orange;
		}
		input{
			width:100%;
			padding:10px;
			box-sizing: border-box;
		}
	</style>
</head>
<body>
	<h1>Login to view your profile</h1>
	<form  method="POST">
		<label for = "username">Username</label>
		<input type="text" name="username" maxlength="10"required><br><br>
		<label for="password">Password</label>
		<input type="password" name="password" maxlength="10"required><br><br>
		<input type="submit" name="submit">		
	</form>
	<?php
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$_SESSION['username']=$_POST["username"];
		$username=$_POST["username"];
		$password=$_POST["password"];
		$sql = "SELECT username,password FROM userdetails where username='$username'";
		$result = $conn->query($sql);
		$qvalue=$result->fetch_assoc();
		if($username==$qvalue["username"])
		{
			if($password==$qvalue["password"])
			{
				echo "<script>location.replace('profile.php')</script>";
			}	
			else
			{
				echo "<script>alert('incorrect password')</script>";
			}
		}
		else
		{
			echo "<script>alert('usernamenot found')</script>";
		}

		$conn->close();
	}
	?>
</body>
</html>