<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db = "profile";
$conn = new mysqli($servername, $username, $password,$db);
if ($conn->connect_error) {
	die("error" . $conn->connect_error);
}
?>